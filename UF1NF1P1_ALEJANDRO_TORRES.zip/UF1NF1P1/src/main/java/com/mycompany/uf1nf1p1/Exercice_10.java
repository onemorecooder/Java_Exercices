/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.uf1nf1p1;

/**
 *
 * @author ajose
 */
public class Exercice_10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        // CREAMOS UNA VARIABLE ALEATORIA QUE IMPRIMA UN NÚMERO DE 100 A 900.
        double a = Math.random()* 900 + 100;

        // LA CONVERTIMOS EN UN ENTERO.
        int numero = (int) a;
        
        // IMPRIMIMOS EL VALOR DE NUESTRO NUMERO EN INT.
        System.out.println("Número int: " + numero);
        
        // HACEMOS DE NUESTRO ENTERO UNA CADENA DE TEXTO.
        String cadena = String.valueOf(numero);
        
        /* CON EL USO DE CHARAT DECIDIREMOS QUE CARACTER
        DE LA CADENA QUEREMOS MOSTRAR, EN ESTE CASO EL VALOR
        DE LA POSICION 0, 1 Y 2 DE NUESTRA CADENA DE TEXTO,
        MOSTRANDO ASÍ UNO POR UNO EL NÚMERO.*/
        System.out.println("El primer número es: " + cadena.charAt(0));
        System.out.println("El segundo número es: " + cadena.charAt(1));
        System.out.println("El tercer número es: " + cadena.charAt(2));
    }
    
}
 