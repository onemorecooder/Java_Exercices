/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.uf1nf1p1;

/**
 *
 * @author ajose
 */
public class Exercice_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        double sobrante;
        
        // GENERAMOS UN NUMERO ALEATORIO DE 0 A 4,9
        double dinero = Math.random() * 5;
        System.out.print("Dinero: ");
        // REDONDEAMOS LA VARIABLE DE DINERO A 2 DECIMALES
        dinero = (int)(dinero*100)/100.0;
        System.out.println(dinero);
        System.out.println("");

        
        /* VAMOS A REALIZAR LA MISMA OPERACIÓN EN TODOS LOS PASOS
        PARA ALCANZAR EL OBJETIVO:
        
        - NUESTRA VARIABLE DE LA MONEDA EN ESTE CASO 2 EUROS LA PASAREMOS A ENTERO.
        Y DIVIDIREMOS NUESTRO DINERO ACTUAL ENTRE LA MONEDA PARA SABER SI NECESITAMOS
        O NO ESTA MONEDA.
        
        - DESPUÉS CALCULAREMOS EL DINERO RESTANTE QUE NOS QUEDA PIDIENDO EL RESTO DE LA DIVISIÓN ANTERIOR 
        Y REDONDEÁNDOLA A LOS DECIMALES NECESARIOS.
        
        ACTO SEGUIDO IMPRIMIMOS EL PROCESO.
        
        */
        int dosEur = (int) (dinero / 2);
        sobrante = (int)((dinero%2)*100)/100.0;
        System.out.println("2 Euros: " + dosEur);
        System.out.println(sobrante);

        int unEur = (int) (sobrante / 1);
        sobrante = (int)((sobrante%1)*100)/100.0;
        System.out.println("1 Euros: " + unEur);
        System.out.println(sobrante);

        int cincuentaCent = (int) (sobrante / 0.50);
        sobrante = (int)((sobrante%0.50)*100)/100.0;
        System.out.println("0.50 Céntimos:: " + cincuentaCent);
        System.out.println(sobrante);

        int veinteCent = (int) (sobrante / 0.20);
        sobrante = (int)((sobrante%0.20)*100)/100.0;
        System.out.println("0.20 Céntimos: " + veinteCent);
        System.out.println(sobrante);

        int diezCent = (int) (sobrante / 0.10);
        sobrante = (int)((sobrante%0.10)*100)/100.0;
        System.out.println("0.10 Céntimos: " + diezCent);
        System.out.println(sobrante);

        int cincoCent = (int) (sobrante / 0.05);
        sobrante = (int)((sobrante%0.05)*100)/100.0;
        System.out.println("0.05 Céntimos: " + cincoCent);
        System.out.println(sobrante);

        int dosCent = (int) (sobrante / 0.02);
        sobrante = (int)((sobrante%0.02)*100)/100.0;
        System.out.println("0.02 Céntimos: " + dosCent);
        System.out.println(sobrante);

        int unCent = (int) (sobrante / 0.01);
        sobrante = (int)((sobrante%0.01)*100)/100.0;
        System.out.println("0.01 Céntimos: " + unCent);
        System.out.println(sobrante);

    }

}
